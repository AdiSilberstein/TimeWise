import flet as ft

def main(page: ft.Page):
    page.title = "TimeWise"
    page.appbar = ft.AppBar(
        title=ft.Text("TimeWise", weight=ft.FontWeight.BOLD, color=ft.colors.BLACK87),
        actions=[],
        bgcolor=ft.colors.BLUE,
        center_title=True,
        color=ft.colors.WHITE,
    )
    page.add(ft.SafeArea(ft.Text("Focus on one thing at a time")))

    def button_clicked(e):
        t.value = f"Textboxes values are:  '{input_task.value}'."
        page.update()

    t = ft.Text()
    input_task = ft.TextField(label="Disabled", disabled=False, hint_text="What is your task for now?") 
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    def handle_change(e):
        page.add(ft.Text(f"TimePicker change: {time_picker.value}"))

    def handle_dismissal(e):
        page.add(ft.Text(f"TimePicker dismissed: {time_picker.value}"))

    def handle_entry_mode_change(e):
        page.add(ft.Text(f"TimePicker Entry mode changed to {e.entry_mode}"))

    time_picker = ft.TimePicker(
        confirm_text="Confirm",
        error_invalid_text="Time out of range",
        help_text="Pick your time slot",
        on_change=handle_change,
        on_dismiss=handle_dismissal,
        on_entry_mode_change=handle_entry_mode_change,
    )

    page.add(
        ft.ElevatedButton(
            "Pick time",
            on_click=lambda _: page.open(time_picker),
        )
    )


    start_working_time = ft.ElevatedButton(text="Start working time", on_click=button_clicked)
    page.add(input_task, start_working_time, t)

ft.app(target=main)